# TikTok → Reels — macOS

```bash
brew install python ffmpeg
pip3 install yt-dlp instagrapi moviepy==2.2.1
cd ~/Downloads/TikTok_to_Reels_macOS
python3 app.py
```

> Don't have Homebrew? Install it first:
> ```bash
> /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
> ```
