# TikTok → Instagram Reels Poster — Ubuntu

## Install dependencies

```bash
sudo apt update
sudo apt install python3 python3-pip python3-tk ffmpeg
pip3 install yt-dlp instagrapi moviepy==2.2.1 --break-system-packages
```

## Run

```bash
python3 app.py
```

## KDE Connect (clipboard sync from phone)

```bash
sudo apt install kdeconnect
kdeconnect-app
```

Install KDE Connect on your Android from the Play Store, pair with your PC, and enable Clipboard Sync in plugin settings.

## Troubleshooting

| Problem | Fix |
|---|---|
| `tkinter` missing | `sudo apt install python3-tk` |
| `ffmpeg not found` | `sudo apt install ffmpeg` |
| Login failed | Turn off 2FA on Instagram or wait an hour |
| Video not found | TikTok link may be private or region-locked |
| pip externally managed | Add `--break-system-packages` to pip install |

## Notes

- Your password is never saved — only a session token is stored locally
- Works with Creator and Business Instagram accounts
- Go to Instagram manually to add your pinned GIF comment after posting
