@echo off
echo Starting TikTok to Instagram Reels...
python app.py
if %errorlevel% neq 0 (
    echo.
    echo Python not found. Please install Python from https://python.org
    pause
)
