# TikTok → Instagram Reels Tool

## Setup (one time only)

1. Make sure Python is installed:
   sudo apt install python3 python3-pip python3-tk

2. Run the app:
   python3 app.py

The app auto-installs yt-dlp and instagrapi on first run.

## How to use

1. Copy a TikTok video link (tap Share → Copy Link on TikTok)
2. Paste it into the app
3. Enter your Instagram username and password
4. Type your caption (it saves it for next time!)
5. Click POST TO REELS — done in ~30 seconds
6. Go to Instagram and manually add your pinned GIF comment

## Tips

- Your caption is saved automatically so you don't retype it every time
- Your login session is cached so logging in is faster after the first time
- Your password is never saved — only the session token is stored locally

## Troubleshooting

- Login failed → make sure 2FA is off on Instagram, or wait an hour and retry
- Download failed → the TikTok may be private or region-locked
- Upload failed → Instagram flagged the login, wait an hour and try again
- Missing tkinter → run: sudo apt install python3-tk
