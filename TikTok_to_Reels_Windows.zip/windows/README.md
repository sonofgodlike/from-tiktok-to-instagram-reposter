# TikTok → Instagram Reels Poster — Windows

## Install dependencies

1. Install Python from https://python.org
   Check "Add Python to PATH" during install!

2. Install ffmpeg via winget:
   ```
   winget install ffmpeg
   ```
   Or download from https://ffmpeg.org/download.html and add bin folder to PATH.

3. Open Command Prompt and run:
   ```
   pip install yt-dlp instagrapi moviepy==2.2.1
   ```

## Run

Double-click START.bat or run in Command Prompt:
```
python app.py
```

## KDE Connect (clipboard sync from phone)

- Download KDE Connect for Windows: https://kdeconnect.kde.org/download.html
- Install KDE Connect on Android from the Play Store
- Pair both devices and enable Clipboard Sync in plugin settings

## Troubleshooting

| Problem | Fix |
|---|---|
| python not found | Re-install Python and check "Add to PATH" |
| ffmpeg not found | Add ffmpeg bin folder to system PATH |
| Login failed | Turn off 2FA on Instagram or wait an hour |
| Video not found | TikTok link may be private or region-locked |

## Notes

- Your password is never saved — only a session token is stored locally
- Works with Creator and Business Instagram accounts
- Go to Instagram manually to add your pinned GIF comment after posting
