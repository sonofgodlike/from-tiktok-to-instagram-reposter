# TikTok → Instagram Reels Poster — Arch Linux

## Install dependencies

```bash
sudo pacman -S python python-pip tk ffmpeg
pip install yt-dlp instagrapi moviepy==2.2.1 --break-system-packages
```

## Run

```bash
python3 app.py
```

## KDE Connect (clipboard sync from phone)

```bash
sudo pacman -S kdeconnect
kdeconnect-app
```

Install KDE Connect on your Android from the Play Store, pair with your PC, and enable Clipboard Sync in plugin settings.

## Troubleshooting

| Problem | Fix |
|---|---|
| `libtk8.6.so` error | `sudo pacman -S tk` |
| `ffmpeg not found` | `sudo pacman -S ffmpeg` |
| Login failed | Turn off 2FA on Instagram or wait an hour |
| Video not found | TikTok link may be private or region-locked |

## Notes

- Your password is never saved — only a session token is stored locally
- Works with Creator and Business Instagram accounts
- Go to Instagram manually to add your pinned GIF comment after posting
